<!DOCTYPE html>
<html>
<head>
    <title>Driver Chart</title>
    <!-- Include necessary CSS and JavaScript files for Chart.js -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/chart.js">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <canvas id="driverChart"></canvas>

    <script>
        // Get the data from the PHP variables passed from the controller
        var levels = <?php echo json_encode($levels, 15, 512) ?>;
        var assignedBins = <?php echo json_encode($assignedBins, 15, 512) ?>;

        // Create the chart
        var ctx = document.getElementById('driverChart').getContext('2d');
        var chart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: levels,
                datasets: [{
                    label: 'Assigned Bins',
                    data: assignedBins,
                    backgroundColor: 'rgba(75, 192, 192, 0.2)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true,
                        precision: 0
                    }
                }
            }
        });
    </script>
</body>
</html>
<?php /**PATH C:\Users\userpc\Desktop\sms\resources\views/driver/chart.blade.php ENDPATH**/ ?>
<table class="table">
    <thead class="thead-light">
      <tr>
        <th scope="col">ID</th>
        <th scope="col">Latitude</th>
        <th scope="col">Longtiude</th>
        <th scope="col">Level</th>
        
        <th scope="col">Action</th>
      </tr>
    </thead>
    <?php $__currentLoopData = $garbages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $garbage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tbody>
      <tr>
        <th><?php echo e($garbage->reg); ?></th>
        <td><?php echo e($garbage->latitude); ?></td>
        <td><?php echo e($garbage->longtiude); ?></td>
        <td><?php echo e($garbage->level); ?></td>
        
        <td>
            <a href="<?php echo e(url('/showg/'.$garbage->id)); ?>" class="bnt btn-sm btn-info">Show</a>
            <a href="<?php echo e(url('/editg/'.$garbage->id)); ?>" class="bnt btn-sm btn-warning">Edit</a>
            <a href="<?php echo e(url('/deleteg/'.$garbage->id)); ?>" class="bnt btn-sm btn-danger">Delete</a>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table><?php /**PATH C:\Users\userpc\Desktop\sms\resources\views/garbagelist.blade.php ENDPATH**/ ?>
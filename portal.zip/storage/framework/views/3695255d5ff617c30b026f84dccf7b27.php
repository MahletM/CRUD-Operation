<table class="table">
    <thead class="thead-light">
      <tr>
        <th scope="col">ID</th>
        <th scope="col">First Name</th>
        <th scope="col">Last Name</th>
        <th scope="col">Email</th>
        <th scope="col">Phone number</th>
        <th scope="col">Action</th>
      </tr>
    </thead>
    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tbody>
      <tr>
        <th><?php echo e($student->reg); ?></th>
        <td><?php echo e($student->firstName); ?></td>
        <td><?php echo e($student->lastName); ?></td>
        <td><?php echo e($student->age); ?></td>
        <td><?php echo e($student->course); ?></td>
        <td>
            <a href="<?php echo e(url('/show/'.$student->id)); ?>" class="bnt btn-sm btn-info">Show</a>
            <a href="<?php echo e(url('/edit/'.$student->id)); ?>" class="bnt btn-sm btn-warning">Edit</a>
            <a href="<?php echo e(url('/delete/'.$student->id)); ?>" class="bnt btn-sm btn-danger">Delete</a>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table><?php /**PATH C:\Users\userpc\Desktop\sms\resources\views/studentlist.blade.php ENDPATH**/ ?>
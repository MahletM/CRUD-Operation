<table class="table">
    <thead class="thead-light">
      <tr>
        <th scope="col">ID</th>
        <th scope="col">First Name</th>
        <th scope="col">Last Name</th>
        <th scope="col">Email</th>
        <th scope="col">Phone number</th>
        <th scope="col">Action</th>
      </tr>
    </thead>
    <?php $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tbody>
      <tr>
        <th><?php echo e($driver->reg); ?></th>
        <td><?php echo e($driver->firstName); ?></td>
        <td><?php echo e($driver->lastName); ?></td>
        <td><?php echo e($driver->email); ?></td>
        <td><?php echo e($driver->phonenumber); ?></td>
        <td>
            <a href="<?php echo e(url('/show/'.$driver->id)); ?>" class="bnt btn-sm btn-info">Show</a>
            <a href="<?php echo e(url('/edit/'.$driver->id)); ?>" class="bnt btn-sm btn-warning">Edit</a>
            <a href="<?php echo e(url('/delete/'.$driver->id)); ?>" class="bnt btn-sm btn-danger">Delete</a>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table><?php /**PATH D:\sms\resources\views/driverlist.blade.php ENDPATH**/ ?>
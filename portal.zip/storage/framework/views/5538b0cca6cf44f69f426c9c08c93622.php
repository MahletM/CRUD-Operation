<!DOCTYPE html>
<html>
<head>
    <title>Driver List</title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>
<body>
    <h2>Driver List</h2>
    
    <h3>Garbages with Level above 75:</h3>
    <?php $__currentLoopData = $garbages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $garbage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($garbage->level > 75): ?>
            <div>
                <h4>Garbage ID: <?php echo e($garbage->id); ?></h4>
                <p>Latitude: <?php echo e($garbage->latitude); ?></p>
                <p>Longitude: <?php echo e($garbage->longtiude); ?></p>
                
                <label for="driver<?php echo e($garbage->id); ?>">Select a driver:</label>
                <select id="driver<?php echo e($garbage->id); ?>" name="driver">
                    <option value="">Choose a driver</option>
                    <?php $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($userName); ?>"><?php echo e($userName); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <br>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <button type="button" onclick="assignDrivers()">Assign</button>

    <script>
        function assignDrivers() {
            var driverData = {};
            
            // Collect selected driver for each garbage
            <?php $__currentLoopData = $garbages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $garbage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($garbage->level > 75): ?>
                    var driverId = document.getElementById("driver<?php echo e($garbage->id); ?>").value;
                    if (driverId) {
                        driverData["<?php echo e($garbage->id); ?>"] = driverId;
                    }
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            // Send the data to the server
            fetch('<?php echo e(route('drivers.assignDriver')); ?>', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                },
                body: JSON.stringify(driverData)
            })
            .then(response => {
                // Handle the response
                if (response.ok) {
                    alert('Drivers assigned successfully');
                    location.reload(); // Refresh the page to update the view
                } else {
                    alert('Error assigning drivers');
                }
            })
            .catch(error => {
                alert('An error occurred: ' + error);
            });
        }
    </script>
</body>
</html>
<?php /**PATH C:\Users\userpc\Desktop\sms\resources\views/driver/index.blade.php ENDPATH**/ ?>
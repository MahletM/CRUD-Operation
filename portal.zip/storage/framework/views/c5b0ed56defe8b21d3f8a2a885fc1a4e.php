<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="<?php echo e(url('/')); ?>">Smart Garbage Collection System</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="<?php echo e(url('/')); ?>">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="<?php echo e(url('/create')); ?>">Register Driver</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="<?php echo e(url('/createg')); ?>">Register Garbage</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="<?php echo e(url('/createg')); ?>">Garbage Info</a>
      </li>
    </ul>
  </div>
</nav><?php /**PATH D:\sms\resources\views/navbar.blade.php ENDPATH**/ ?>